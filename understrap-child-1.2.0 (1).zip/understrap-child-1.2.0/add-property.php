<?php
/*
Template Name: Add Property
*/

get_header();

if ( isset( $_POST['property_title'] ) ) {
    $new_property = array(
        'post_title'   => $_POST['property_title'],
        'post_type'    => 'realty',
        'post_status'  => 'publish',
        'post_content' => '',
    );

    $property_id = wp_insert_post( $new_property );

    if ( $property_id ) {
        if ( isset( $_POST['property_city'] ) ) {
            update_post_meta( $property_id, 'selected_city', $_POST['property_city'] );
        }

        echo 'Объект недвижимости успешно добавлен!';
    } else {
        echo 'Ошибка при добавлении объекта недвижимости.';
    }

    exit;
}
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div id="content" class="container">

            <form id="add-property-form">
                <div>
                    <label for="property-title">Заголовок объекта недвижимости:</label>
                    <input type="text" name="property_title" id="property-title" required>
                </div>
                <div>
                    <label for="property-city">Город:</label>
                    <select name="property_city" id="property-city" required>
                        <option value="">-- Выберите город --</option>
                        <?php
                        $cities = get_posts( array( 'post_type' => 'city', 'numberposts' => -1 ) );
                        foreach ( $cities as $city ) {
                            echo '<option value="' . $city->ID . '">' . $city->post_title . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div>
                    <input type="submit" value="Добавить">
                </div>
            </form>

        </div>
    </main>
</div>

<script>
    jQuery(document).ready(function ($) {
        $('#add-property-form').submit(function (e) {
            e.preventDefault();

            var form = $(this);
            var formData = form.serialize();

            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                data: formData,
                success: function (response) {
                    alert(response); // или используйте другой способ для отображения успешного сообщения
                    form.trigger('reset');
                }
            });
        });
    });
</script>

<?php
get_footer();
?>