jQuery(document).ready(function ($) {
    $('#add-property-form').submit(function (e) {
        e.preventDefault();

        var form = $(this);
        var formData = form.serialize();

        $.ajax({
            type: 'POST',
            url: ajax_object.ajax_url + '?action=add_property',
            data: formData,
            success: function (response) {
                alert(response);
                form.trigger('reset');
            }
        });
    });
});
